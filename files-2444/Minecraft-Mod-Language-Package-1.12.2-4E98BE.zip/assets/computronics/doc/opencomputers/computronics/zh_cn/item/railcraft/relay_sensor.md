# 数字化中继器传感器

![单次使用。](item:computronics:relay_sensor)

数字化中继器传感器的用途是将[数字化机车中继器](../../block/railcraft/locomotive_relay.md)与Railcraft模组的电力机车进行配对。配对过程为：先手持中继器传感器潜行右键单击[数字化机车中继器](../../block/railcraft/locomotive_relay.md)，然后潜行左键单击电力机车，以将中继器传感器附于其上。
