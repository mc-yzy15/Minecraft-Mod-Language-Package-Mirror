# 计算电子学手册

此索引列出了计算电子学模组提供的所有TIS-3D模块。

## 模块
* [变色模块](colorful_module.md)
* [磁带机模块](tape_reader_module.md)
* [自毁模块](self_destructing_module.md)
* 
