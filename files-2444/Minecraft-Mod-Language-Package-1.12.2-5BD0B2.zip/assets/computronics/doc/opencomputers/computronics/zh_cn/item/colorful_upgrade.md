# 变色升级

![漂亮的很呐。](item:computronics:oc_parts@7)

此升级只能安装到机器人中。它提供了一个名为`colors`的组件，可用于修改机器人外壳的颜色。调用`robot.setLightColor`函数即可修改颜色，让你的机器人变得俊上加俊。
