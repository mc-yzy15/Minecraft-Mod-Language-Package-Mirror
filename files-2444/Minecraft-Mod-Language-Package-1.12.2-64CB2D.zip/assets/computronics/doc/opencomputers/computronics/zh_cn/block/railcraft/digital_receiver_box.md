# 数字化信号接收盒

![数字化接收。](block:computronics:digital_box@0)

数字化信号接收盒可用于探测信号状态变化，线缆需要连接到控制盒的上或下面。信号状态由Railcraft模组的[信号](http://railcraft.info/wiki/guide:signalling)文档定义（信号状态包含绿灯、闪烁黄灯、黄灯、闪烁红灯以及红灯）。

接收盒可连接到至多32个不同的控制盒。控制盒通过名称区分，名称可由信号标签指定。
