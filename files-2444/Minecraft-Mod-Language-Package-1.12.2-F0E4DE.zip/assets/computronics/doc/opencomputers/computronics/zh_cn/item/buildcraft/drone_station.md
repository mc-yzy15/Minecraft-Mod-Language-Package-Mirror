# 无人机停靠站

![下半部分。](item:computronics:drone_station)

无人机停靠站可安装到Buildcraft模组的管道上，以供装有[无人机停靠升级](docking_upgrade.md)的无人机停靠。无人机停靠后可将自身装载的物品输入进Buildcraft的管道网络中，若管道为能量管道，停靠站还可为无人机充电。
