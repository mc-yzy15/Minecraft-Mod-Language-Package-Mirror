---
id: plc_workbenches
---
# PLC工作站

工作站中的物品和实体可由PLC操作机构操纵。

## 示例：

- 展示台（物品）
- 启智台座（物品）
- 手术站（实体）

不是所有指令的执行都要求存在工作站。有部分指令只涉及普通的物品存储空间和流体储罐。

\image[width=854,height=480,scale=0.6]{neepmeat:guide/images/plc_workbenches.png}
\centering{左至右：展示台、启智台座、手术站。}