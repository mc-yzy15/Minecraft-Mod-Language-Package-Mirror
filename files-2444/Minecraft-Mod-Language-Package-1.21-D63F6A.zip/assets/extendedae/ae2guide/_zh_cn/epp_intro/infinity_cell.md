---
navigation:
    parent: epp_intro/epp_intro-index.md
    title: ME无限元件
    icon: extendedae:infinity_water_cell
categories:
- extended items
item_ids:
- extendedae:infinity_water_cell
- extendedae:infinity_cobblestone_cell
---

# ME无限元件

简单的水和圆石储库，套上了存储元件的外壳。

<Row>
<ItemImage id="extendedae:infinity_water_cell" scale="4"></ItemImage>
<ItemImage id="extendedae:infinity_cobblestone_cell" scale="4"></ItemImage>
</Row>

此类元件中装有约21亿单位的物品/流体，且可从中无限取出圆石/水，也可向其中无限存入圆石/水。
