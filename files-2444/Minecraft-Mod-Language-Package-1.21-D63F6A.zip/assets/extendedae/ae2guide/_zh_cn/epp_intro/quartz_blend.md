---
navigation:
  parent: epp_intro/epp_intro-index.md
  title: 石英混合物
  icon: extendedae:quartz_blend
categories:
  - extended foundation
item_ids:
  - extendedae:quartz_blend
---

# 石英混合物

<Row>
<ItemImage id="extendedae:quartz_blend" scale="4"></ItemImage>
</Row>

石英、煤炭、沙子组成的混合物。相比于直接烧炼赛特斯石英粉而言，烧炼此混合物产出的<ItemLink id="ae2:silicon" />更多。

