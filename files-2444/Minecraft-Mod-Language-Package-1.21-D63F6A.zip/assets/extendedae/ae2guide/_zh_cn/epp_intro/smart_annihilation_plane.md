---
navigation:
    parent: epp_intro/epp_intro-index.md
    title: ME智能破坏面板
    icon: extendedae:smart_annihilation_plane
categories:
- extended devices
item_ids:
- extendedae:smart_annihilation_plane
---

# ME智能破坏面板

<GameScene zoom="8" background="transparent">
  <ImportStructure src="../structure/cable_smart_annihilation_plane.snbt"></ImportStructure>
</GameScene>

ME智能破坏面板是能根据配置栏破坏方块或吸收物品的<ItemLink id="ae2:annihilation_plane" />。

智能破坏面板不需要专门设置子网。它类似于不从箱子里输入、而是会破坏方块的<ItemLink id="ae2:import_bus" />。