---
navigation:
  title: 苍穹晶砧
  icon: "justdynathings:celestigem_anvil"
  position: 3
  parent: justdynathings:anvils.md
item_ids:
  - justdynathings:celestigem_anvil
---

# 苍穹晶砧

使用Forge能量（Forge Energy，FE）修复物品的砧。

<BlockImage id="justdynathings:celestigem_anvil" scale="4.0"/>

<RecipeFor id="justdynathings:celestigem_anvil" />
