---
navigation:
  title: 其他
  icon: "justdynathings:stabilizer"
  position: 99
---

# 其他

无法分类的其他方块和物品⸺但绝对不是没用！

<SubPages />
