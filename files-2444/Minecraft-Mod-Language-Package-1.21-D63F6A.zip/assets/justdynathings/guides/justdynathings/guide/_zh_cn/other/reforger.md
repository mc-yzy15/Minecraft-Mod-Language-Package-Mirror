---
navigation:
  title: 再造器
  icon: "justdynathings:reforger"
  position: 2
  parent: justdynathings:other.md
item_ids:
  - justdynathings:reforger
---

# 再造器

一台强大的机器，可消耗*催化剂*将放置于*红色面*的输入方块变成*输出方块*。

<BlockImage id="justdynathings:reforger" p:facing="up" p:active="true" scale="4.0"/>

<Recipe id="justdynathings:reforger" />

## 默认配方
