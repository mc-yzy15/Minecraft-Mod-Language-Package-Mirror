---
navigation:
  title: 新手杖
  icon: "justdynathings:swapper_wand"
  position: 5
---

# 新手杖

有特殊效果的新物品。

<CategoryIndex category="wands"></CategoryIndex>
