---
navigation:
  title: 光源手杖
  icon: "justdynathings:light_wand"
  position: 5
  parent: justdynathings:wands.md
item_ids:
  - justdynathings:light_wand
---

# 要有光！

一套全新的手杖，能放置和破坏光源方块。也可以给予所看的实体发光效果。

使用时消耗耐久度。

<ItemImage id="justdynathings:light_wand" scale="4.0"/>

<Recipe id="justdynathings:light_wand" />
