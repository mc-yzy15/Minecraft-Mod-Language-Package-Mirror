---
navigation:
  title: 拾取手杖
  icon: "justdynathings:picker_wand"
  position: 2
  parent: justdynathings:wands.md
item_ids:
  - justdynathings:picker_wand
---

# 拾取手杖

可以拾起方块再放到其他位置的手杖。

<ItemImage id="justdynathings:picker_wand" scale="4.0"/>

<Recipe id="justdynathings:picker_wand" />
