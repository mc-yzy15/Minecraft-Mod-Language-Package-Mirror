---
navigation:
  title: 转化瓮
  icon: "synergy:urn"
  parent: magic.md
  position: 1
categories:
  - magic
item_ids:
  - synergy:urn
---

# 转化瓮

用于融合物品的功能方块。

它能容纳九个物品堆叠。

使用物品右击即可将其放入转化瓮。

转化瓮没有GUI，但可用漏斗和类似物件自动化。

<ItemImage id="synergy:urn" scale="4.0"/>

<RecipeFor id="synergy:urn" />
