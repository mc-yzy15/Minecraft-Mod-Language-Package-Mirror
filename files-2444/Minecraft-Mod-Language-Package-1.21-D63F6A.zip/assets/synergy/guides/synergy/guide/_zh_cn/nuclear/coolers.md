---
navigation:
  title: 冷却器
  icon: "synergy:cooler_base"
  parent: nuclear.md
  position: 4
categories:
  - nuclear
item_ids:
- synergy:shadow_cooler
- synergy:copper_cooler
- synergy:diamond_cooler
- synergy:emerald_cooler
- synergy:ender_cooler
- synergy:frost_cooler
- synergy:glowstone_cooler
- synergy:gold_cooler
- synergy:iron_cooler
- synergy:lapis_cooler
- synergy:netherite_cooler
- synergy:quartz_cooler
- synergy:redstone_cooler
- synergy:sculk_cooler
- synergy:water_cooler
---

# 冷却器

量子反应堆的组成部分。

可在特定环境条件下减少热量。