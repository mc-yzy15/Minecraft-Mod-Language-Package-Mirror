---
navigation:
  title: 木钩子
  icon: "synergy:wooden_crook"
  parent: tools.md
  position: 1
categories:
  - tools
item_ids:
  - synergy:wooden_crook
---

# 木钩子

类似锄的工具，能增加所破坏方块掉落稀有掉落物的概率。

<ItemImage id="synergy:wooden_crook" scale="4.0"/>

<RecipeFor id="synergy:wooden_crook" />
