---
navigation:
    parent: machines-blocks/machines-blocks-index.md
    title: "工厂核心"
    icon: "woot_revived:heart"
---
# 工厂核心

<BlockImage id="heart" scale="5"/>

<ItemImage id="heart" scale="0.5"/>工厂核心是工厂的主控制器

它能帮助你监控工厂状态，显示剩余的<ItemImage id="vitality_fuel_fluid_bucket" scale="0.5"/>生命燃料流体、安装的升级、<ItemImage id="fake_spawner" scale="0.5"/>伪刷怪笼正在模拟的生物、每种生物的进度，以及生物模拟所需输入的物品或流体

## 合成

<RecipeFor id="heart" />