---
navigation:
    parent: machines-blocks/machines-blocks-index.md
    title: "原料输入口"
    icon: "woot_revived:import"
---
# 原料输入口

<BlockImage id="import" scale="5" p:attached="true" />

<ItemImage id="import" scale="0.5"/>原料输入口用于输入生成生物所需的物品或流体

可将装有物品/流体的箱子/储罐与其相邻放置。也可使用管道输入。

注意！所有输入该方块的物品或流体都将直接销毁！
该操作无法撤回

别担心，该方块会自动抽入生物模拟所需的物品或流体，不多也不少

## 合成

<RecipeFor id="import" />