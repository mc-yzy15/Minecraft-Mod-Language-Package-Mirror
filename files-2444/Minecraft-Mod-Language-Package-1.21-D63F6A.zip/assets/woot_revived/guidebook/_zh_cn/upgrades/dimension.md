---
navigation:
    parent: upgrades/upgrades-index.md
    title: "维度升级"
    icon: "woot_revived:end_dimension_upgrade"
    position: 1
---
# 维度升级

<Row>
  <ItemImage id="nether_dimension_upgrade" scale="3"/>
  <ItemImage id="end_dimension_upgrade" scale="3"/>
</Row>

维度升级能够改变模拟的维度

## 下界维度升级

将维度设置为下界

<RecipeFor id="nether_dimension_upgrade" />

## 末地维度升级

将维度设置为末地

<RecipeFor id="end_dimension_upgrade" />